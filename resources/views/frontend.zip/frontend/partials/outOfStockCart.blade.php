<div class="modal-body p-4 added-to-cart">
    <div class="text-center text-danger">
        <h2>{{__('oops..')}}</h2>
        <h3>{{__('This item is out of stock!')}}</h3>
    </div>
    <div class="text-center mt-5">
        <button class="btn btn-styled btn-base-1 btn-outline" data-dismiss="modal">{{__('Back to shopping')}}</button>
    </div>
</div>
