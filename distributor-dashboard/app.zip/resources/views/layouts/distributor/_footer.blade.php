<strong>{{date('Y')}} &copy;  <a href="#">www.suqbahrain.com</a></strong>

<div class="float-right d-none d-sm-inline-block">
    Anything you want
</div>
