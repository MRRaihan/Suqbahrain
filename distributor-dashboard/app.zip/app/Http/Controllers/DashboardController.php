<?php

namespace App\Http\Controllers;

use App\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{
    public function login(){
        return view('distributor.login');
    }
    public function dashboard(){
        $merchant_today = User::where('distributor_id', Auth::user()->id)
            ->whereDate('created_at',Carbon::today())->count();
        $total_merchant = User::where('distributor_id', Auth::user()->id)->count();
        return view('distributor.dashboard', compact('total_merchant', 'merchant_today'));
    }
}
