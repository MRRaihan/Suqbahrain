<strong><?php echo e(date('Y')); ?> &copy;  <a href="#">www.suqbahrain.com</a></strong>

<div class="float-right d-none d-sm-inline-block">
    Anything you want
</div>
<?php /**PATH /home/suqbahra/public_html/distributor-dashboard/resources/views/layouts/distributor/_footer.blade.php ENDPATH**/ ?>