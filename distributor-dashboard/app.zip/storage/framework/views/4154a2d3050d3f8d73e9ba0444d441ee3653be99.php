<?php $__env->startSection('title', 'Merchant List'); ?>
<?php $__env->startSection('table_css'); ?>
    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/distributor/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/distributor/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-head'); ?>
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Dashboard</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('distributor.dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item">Merchant List</li>

                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <a style="float: right;" href="<?php echo e(route('merchant.create')); ?>" class="btn btn-rounded btn-info pull-right"><?php echo e(__('Add New Merchant')); ?></a>
        </div>
    </div>

    <br>

    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Merchant List</h3>
        </div>
        <!-- /.card-header -->
        <div class="card-body">
            <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                    <th width="5%">SL#</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Type</th>
                    <th>Distributor</th>
                    <th width="14%">Actions</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $merchants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $merchant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($merchant != null): ?>
                        <tr>
                            <td><?php echo e($key+1); ?></td>
                            <td><?php echo e($merchant->name); ?></td>
                            <td><?php echo e($merchant->email); ?></td>
                            <td><?php echo e($merchant->phone); ?></td>
                            <td>
                                <?php if($merchant->is_merchant == 1): ?> Merchant <?php endif; ?>
                            </td>
                            <td><?php echo e($merchant->distributor->name); ?></td>
                            <td class="d-flex">
                                <a class="btn btn-info btn-sm d-inline-block" href="<?php echo e(route('merchant.edit', encrypt($merchant->id))); ?>">Edit</a>
                                <form class="d-inline-block pull-right" method="post" action="<?php echo e(route('merchant.destroy', $merchant->id)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button class="btn btn-danger btn-sm ml-2" onclick="return confirm('Are you confirm?')">Delete</button>
                                </form>
                            </td>
                        </tr>
                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <!-- /.card-body -->
    </div>
    <!-- /.card -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('table_script'); ?>

    <!-- DataTables -->
    <script src="<?php echo e(asset('assets/distributor/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/distributor/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/distributor/plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/distributor/plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>

    <script>
        $(function () {
            $("#example1").DataTable({
                "responsive": true,
                "autoWidth": false,
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.distributor.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Distributor\resources\views/distributor/merchant/index.blade.php ENDPATH**/ ?>