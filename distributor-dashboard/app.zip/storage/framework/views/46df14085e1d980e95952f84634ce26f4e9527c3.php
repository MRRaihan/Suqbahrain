<!-- Sidebar -->
<div class="sidebar">
    <!-- Sidebar user panel (optional) -->
    <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
            <img src="<?php echo e(asset('assets/distributor/dist/img/user2-160x160.jpg')); ?>" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
            <a href="<?php echo e(route('distributor.dashboard')); ?>" class="d-block"><?php echo e(auth()->user()->name); ?></a>
        </div>
    </div>

    <!-- Sidebar Menu -->
    <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
            <!-- Add icons to the links using the .nav-icon class
                 with font-awesome or any other icon font library -->
            <li class="nav-item has-treeview menu-open">
                <?php
                    $dashboard_url = Request::is('distributor/dashboard')
                ?>
                <a href="<?php echo e(route('distributor.dashboard')); ?>" class="nav-link <?php echo e($dashboard_url ? 'active' : ''); ?>">
                    <p class="ml-5">Dashboard</p>
                </a>
            </li>
            <?php
                $merchant_manu = Request::is('merchant')
            ?>
            <li class="nav-item has-treeview <?php echo e($merchant_manu ? 'menu-open' : ''); ?>">
                <?php
                    $merchant_url = Request::is('merchant')
                ?>
                <a  class="nav-link <?php echo e($merchant_url ? 'active' : ''); ?>">
                    <i class="nav-icon fa fa-user"></i>
                    <p>
                        Merchants
                        <i class="fas fa-angle-left right"></i>
                    </p>
                </a>
                <ul class="nav nav-treeview">

                    <li class="nav-item">
                        <a href="<?php echo e(route('merchant.index')); ?>" class="nav-link <?php echo e($merchant_url ? 'active' : ''); ?>">
                            <i class="far fa-circle nav-icon"></i>
                            <p>All merchant</p>
                        </a>
                    </li>
                </ul>
            </li>
        </ul>
    </nav>
    <!-- /.sidebar-menu -->
</div>
<!-- /.sidebar -->
<?php /**PATH C:\xampp\htdocs\Distributor\resources\views/layouts/distributor/_leftNav.blade.php ENDPATH**/ ?>