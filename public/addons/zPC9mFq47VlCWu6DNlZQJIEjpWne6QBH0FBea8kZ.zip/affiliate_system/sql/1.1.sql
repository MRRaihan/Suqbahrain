INSERT INTO `affiliate_options` (`id`, `type`, `details`, `percentage`, `status`, `created_at`, `updated_at`) VALUES (NULL, 'category_wise_affiliate', NULL, '0', '0', current_timestamp(), current_timestamp());
COMMIT;
